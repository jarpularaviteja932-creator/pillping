import tempfile
import unittest
from datetime import date
from pathlib import Path
from habit_tracker.models import HabitRecord
from habit_tracker.analytics import weekly_summary, week_start, build_report
from habit_tracker.storage import import_csv

class HabitTrackerTests(unittest.TestCase):
    def test_record_rejects_out_of_range_hydration(self):
        record = HabitRecord("2026-11-24", hydration=31)
        with self.assertRaises(ValueError):
            record.validate()

    def test_record_rejects_bad_date(self):
        with self.assertRaises(ValueError):
            HabitRecord("24-11-2026").validate()

    def test_week_starts_on_monday(self):
        self.assertEqual(week_start(date(2026, 11, 24)), date(2026, 11, 23))

    def test_weekly_totals(self):
        records = [
            HabitRecord("2026-11-23", reading=20, exercise=30, hydration=8),
            HabitRecord("2026-11-24", reading=10, exercise=0, hydration=6),
        ]
        summary = weekly_summary(records, date(2026, 11, 24))
        self.assertEqual(summary["metrics"]["reading"]["total"], 30)
        self.assertEqual(summary["metrics"]["hydration"]["goal_days"], 1)

    def test_report_contains_week(self):
        summary = weekly_summary([], date(2026, 11, 24))
        self.assertIn("2026-11-23", build_report(summary))

    def test_csv_import_reports_bad_rows(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "input.csv"
            path.write_text(
                "entry_date,reading,exercise,hydration,note\n"
                "2026-11-23,10,20,8,ok\n"
                "bad-date,abc,20,8,nope\n",
                encoding="utf-8"
            )
            records, errors = import_csv(path)
            self.assertEqual(len(records), 1)
            self.assertEqual(len(errors), 1)

if __name__ == "__main__":
    unittest.main()
