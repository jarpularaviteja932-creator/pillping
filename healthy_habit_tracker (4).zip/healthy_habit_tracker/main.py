"""Entry point for the Healthy Habit Tracker."""
from habit_tracker.cli import run

if __name__ == "__main__":
    run()
