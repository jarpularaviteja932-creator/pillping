"""Weekly totals, averages, goal checks, and report generation."""
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path
from .models import HABITS, HabitRecord

DEFAULT_GOALS = {"reading": 20, "exercise": 30, "hydration": 8}

def week_start(day: date) -> date:
    return day - timedelta(days=day.weekday())

def weekly_summary(records: list[HabitRecord], anchor: date | None = None) -> dict:
    anchor = anchor or date.today()
    start = week_start(anchor)
    end = start + timedelta(days=6)
    selected = [r for r in records if start.isoformat() <= r.entry_date <= end.isoformat()]
    by_day = {r.entry_date: r for r in selected}
    metrics = {}
    for habit, rules in HABITS.items():
        values = [getattr(r, habit) for r in selected]
        total = sum(values)
        metrics[habit] = {
            "total": total,
            "average": round(total / 7, 1),
            "active_day_average": round(total / len(values), 1) if values else 0,
            "goal": DEFAULT_GOALS[habit],
            "goal_days": sum(value >= DEFAULT_GOALS[habit] for value in values),
            "unit": rules["unit"],
        }
    return {"start": start, "end": end, "records": selected, "by_day": by_day, "metrics": metrics}

def build_report(summary: dict) -> str:
    lines = [
        f"# Healthy Habit Tracker — Week of {summary['start'].isoformat()}",
        "",
        f"Entries recorded: {len(summary['records'])} of 7 days",
        "",
        "| Habit | Weekly total | Daily average (7 days) | Goal days |",
        "|---|---:|---:|---:|",
    ]
    for habit, metric in summary["metrics"].items():
        lines.append(
            f"| {habit.title()} | {metric['total']} {metric['unit']} | "
            f"{metric['average']} | {metric['goal_days']} |"
        )
    lines += ["", "## Daily entries", "", "| Date | Reading (min) | Exercise (min) | Hydration (glasses) |", "|---|---:|---:|---:|"]
    for record in sorted(summary["records"], key=lambda r: r.entry_date):
        lines.append(f"| {record.entry_date} | {record.reading} | {record.exercise} | {record.hydration} |")
    return "\n".join(lines) + "\n"

def save_chart(summary: dict, destination: Path) -> tuple[bool, str]:
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return False, "Matplotlib is not installed. Run: pip install -r requirements.txt"
    dates = [(summary["start"] + timedelta(days=i)).strftime("%a") for i in range(7)]
    habits = ["reading", "exercise", "hydration"]
    fig, axes = plt.subplots(3, 1, figsize=(9, 8), constrained_layout=True)
    for axis, habit in zip(axes, habits):
        values = [
            getattr(summary["by_day"].get((summary["start"] + timedelta(days=i)).isoformat(),
                                         HabitRecord((summary["start"] + timedelta(days=i)).isoformat())), habit)
            for i in range(7)
        ]
        axis.plot(dates, values, marker="o", linewidth=2)
        axis.set_title(f"{habit.title()} ({HABITS[habit]['unit']})")
        axis.grid(True, alpha=0.25)
        axis.set_ylabel("Amount")
    fig.suptitle("Your weekly habit trends")
    destination.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(destination, dpi=160)
    plt.close(fig)
    return True, f"Chart saved to {destination}"
