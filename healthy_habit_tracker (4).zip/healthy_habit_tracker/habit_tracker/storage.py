"""Local JSON and CSV storage with defensive handling of damaged files."""
import csv
import json
from pathlib import Path
from typing import List
from .models import HabitRecord

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
JSON_FILE = DATA_DIR / "records.json"
CSV_FILE = DATA_DIR / "records.csv"
FIELDS = ["entry_date", "reading", "exercise", "hydration", "note"]

def ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

def load_records() -> List[HabitRecord]:
    ensure_data_dir()
    if not JSON_FILE.exists():
        save_records([])
        return []
    try:
        raw = json.loads(JSON_FILE.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise ValueError("The records file must contain a JSON list.")
        records = []
        for index, item in enumerate(raw, start=1):
            try:
                records.append(HabitRecord.from_dict(item))
            except (ValueError, TypeError, KeyError) as exc:
                print(f"Warning: skipped damaged record #{index}: {exc}")
        return records
    except (json.JSONDecodeError, OSError, ValueError) as exc:
        backup = JSON_FILE.with_suffix(".corrupt.json")
        try:
            JSON_FILE.replace(backup)
            print(f"Warning: damaged data moved to {backup.name}: {exc}")
        except OSError:
            print(f"Warning: could not read saved data: {exc}")
        save_records([])
        return []

def save_records(records: List[HabitRecord]) -> None:
    ensure_data_dir()
    payload = [record.to_dict() for record in sorted(records, key=lambda r: r.entry_date)]
    temporary = JSON_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    temporary.replace(JSON_FILE)
    export_csv(records)

def export_csv(records: List[HabitRecord], destination: Path = CSV_FILE) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        for record in sorted(records, key=lambda r: r.entry_date):
            writer.writerow(record.to_dict())

def import_csv(source: Path) -> tuple[list[HabitRecord], list[str]]:
    imported, errors = [], []
    with source.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        missing = set(FIELDS) - set(reader.fieldnames or [])
        if missing:
            raise ValueError("CSV is missing columns: " + ", ".join(sorted(missing)))
        for row_number, row in enumerate(reader, start=2):
            try:
                imported.append(HabitRecord(
                    entry_date=row["entry_date"].strip(),
                    reading=int(row["reading"]),
                    exercise=int(row["exercise"]),
                    hydration=int(row["hydration"]),
                    note=(row.get("note") or "").strip(),
                ))
                imported[-1].validate()
            except (ValueError, TypeError) as exc:
                errors.append(f"Row {row_number}: {exc}")
    return imported, errors
