"""Friendly terminal interface for Healthy Habit Tracker."""
from datetime import date
from pathlib import Path
from .models import HabitRecord, HABITS
from .storage import load_records, save_records, import_csv, export_csv
from .analytics import weekly_summary, build_report, save_chart

ROOT = Path(__file__).resolve().parents[1]

def ask_int(prompt: str, minimum: int, maximum: int) -> int:
    while True:
        raw = input(prompt).strip()
        try:
            value = int(raw)
            if minimum <= value <= maximum:
                return value
            print(f"Please enter a value from {minimum} to {maximum}.")
        except ValueError:
            print("Please enter a whole number (for example, 25).")

def ask_date(prompt: str = "Date (YYYY-MM-DD, Enter for today): ") -> str:
    while True:
        raw = input(prompt).strip()
        if not raw:
            return date.today().isoformat()
        try:
            return date.fromisoformat(raw).isoformat()
        except ValueError:
            print("That date doesn't look right. Use YYYY-MM-DD.")

def add_entry(records: list[HabitRecord]) -> None:
    print("\nLet's record a day. Use 0 if you did not do an activity.")
    day = ask_date()
    values = {}
    for habit, rules in HABITS.items():
        values[habit] = ask_int(
            f"{habit.title()} ({rules['unit']}): ",
            rules["minimum"], rules["maximum"]
        )
    note = input("Short note (optional, max 200 characters): ").strip()[:200]
    new_record = HabitRecord(day, note=note, **values)
    new_record.validate()
    # One record per date: updating avoids confusing duplicate daily totals.
    records[:] = [r for r in records if r.entry_date != day]
    records.append(new_record)
    save_records(records)
    print("Saved. Your entry is safely stored on this computer.")

def show_records(records: list[HabitRecord]) -> None:
    if not records:
        print("\nNo entries yet. Choose option 1 to add your first day.")
        return
    query = input("Search by date, habit value, or note (Enter for all): ").strip().lower()
    matches = []
    for r in sorted(records, key=lambda item: item.entry_date, reverse=True):
        line = f"{r.entry_date} | Reading {r.reading}m | Exercise {r.exercise}m | Water {r.hydration} glasses | {r.note}"
        if not query or query in line.lower():
            matches.append(line)
    if not matches:
        print("No matching entries found.")
    else:
        print("\n" + "\n".join(matches[:30]))
        if len(matches) > 30:
            print(f"...and {len(matches) - 30} more. Search by date to narrow the list.")

def show_summary(records: list[HabitRecord]) -> None:
    anchor = date.fromisoformat(ask_date("Choose a date in the week (Enter for today): "))
    summary = weekly_summary(records, anchor)
    print(f"\nWEEKLY SUMMARY: {summary['start']} to {summary['end']}")
    print(f"Days with entries: {len(summary['records'])}/7")
    for habit, metric in summary["metrics"].items():
        print(f"\n{habit.title()}: {metric['total']} {metric['unit']} total")
        print(f"  Daily average: {metric['average']} {metric['unit']}")
        print(f"  Goal met: {metric['goal_days']} day(s) (goal: {metric['goal']} {metric['unit']}/day)")
        if metric["goal_days"] == 0:
            print("  Tip: Try a small, realistic target tomorrow.")
    reports = ROOT / "reports"
    reports.mkdir(exist_ok=True)
    report_path = reports / f"weekly-report-{summary['start']}.md"
    report_path.write_text(build_report(summary), encoding="utf-8")
    print(f"\nReadable report saved: {report_path.relative_to(ROOT)}")
    chart_path = ROOT / "charts" / f"weekly-trends-{summary['start']}.png"
    ok, message = save_chart(summary, chart_path)
    print(message)

def import_entries(records: list[HabitRecord]) -> None:
    raw = input("Path to CSV file: ").strip().strip('"')
    try:
        incoming, errors = import_csv(Path(raw).expanduser())
        known = {r.entry_date: r for r in records}
        for record in incoming:
            known[record.entry_date] = record
        records[:] = list(known.values())
        save_records(records)
        print(f"Imported or updated {len(incoming)} valid row(s).")
        for error in errors[:10]:
            print(" - " + error)
        if len(errors) > 10:
            print(f" - and {len(errors) - 10} more row error(s).")
    except (OSError, ValueError) as exc:
        print(f"Could not import that file: {exc}")

def seed_demo(records: list[HabitRecord]) -> None:
    if records:
        answer = input("This adds demo entries and may replace matching dates. Continue? (y/N): ").strip().lower()
        if answer != "y":
            return
    from datetime import timedelta
    today = date.today()
    demo = []
    for offset in range(39, -1, -1):
        day = today - timedelta(days=offset)
        # Deterministic, varied sample values; no third-party data required.
        demo.append(HabitRecord(
            day.isoformat(),
            reading=[10, 20, 35, 0, 25][offset % 5],
            exercise=[0, 15, 30, 45, 20, 10][offset % 6],
            hydration=[4, 6, 8, 10, 7, 9, 5][offset % 7],
            note="Sample entry" if offset % 4 == 0 else ""
        ))
    known = {r.entry_date: r for r in records}
    known.update({r.entry_date: r for r in demo})
    records[:] = list(known.values())
    save_records(records)
    print("Added 40 realistic demo days. You can remove data/records.json to start fresh.")

def run() -> None:
    records = load_records()
    while True:
        print("\n" + "=" * 48)
        print("          HEALTHY HABIT TRACKER")
        print("=" * 48)
        print("1. Add or update today's habit record")
        print("2. View and search records")
        print("3. Weekly summary and chart")
        print("4. Import records from CSV")
        print("5. Export all records to CSV")
        print("6. Load 40 sample entries (demo)")
        print("0. Save and exit")
        choice = input("\nChoose an option: ").strip()
        if choice == "1":
            add_entry(records)
        elif choice == "2":
            show_records(records)
        elif choice == "3":
            show_summary(records)
        elif choice == "4":
            import_entries(records)
        elif choice == "5":
            destination = input("CSV path (Enter for data/records.csv): ").strip()
            path = Path(destination).expanduser() if destination else ROOT / "data" / "records.csv"
            try:
                export_csv(records, path)
                print(f"Exported {len(records)} record(s) to {path}")
            except OSError as exc:
                print(f"Export failed: {exc}")
        elif choice == "6":
            seed_demo(records)
        elif choice == "0":
            save_records(records)
            print("Your records are saved. Take care!")
            break
        else:
            print("Please choose one of the menu options (0–6).")
