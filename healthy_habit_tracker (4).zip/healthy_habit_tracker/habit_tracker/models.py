"""Small data model and validation helpers for habit records."""
from dataclasses import dataclass, asdict
from datetime import date
from typing import Dict

HABITS = {
    "reading": {"unit": "minutes", "minimum": 0, "maximum": 1440},
    "exercise": {"unit": "minutes", "minimum": 0, "maximum": 1440},
    "hydration": {"unit": "glasses", "minimum": 0, "maximum": 30},
}

@dataclass
class HabitRecord:
    entry_date: str
    reading: int = 0
    exercise: int = 0
    hydration: int = 0
    note: str = ""

    def validate(self) -> None:
        try:
            date.fromisoformat(self.entry_date)
        except (TypeError, ValueError) as exc:
            raise ValueError("Date must use YYYY-MM-DD format.") from exc

        for habit, rules in HABITS.items():
            value = getattr(self, habit)
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{habit.title()} must be a whole number.")
            if not rules["minimum"] <= value <= rules["maximum"]:
                raise ValueError(
                    f"{habit.title()} must be between {rules['minimum']} "
                    f"and {rules['maximum']} {rules['unit']}."
                )
        if not isinstance(self.note, str) or len(self.note) > 200:
            raise ValueError("Note must be text with at most 200 characters.")

    def to_dict(self) -> Dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict) -> "HabitRecord":
        allowed = {"entry_date", "reading", "exercise", "hydration", "note"}
        cleaned = {key: data[key] for key in allowed if key in data}
        record = cls(**cleaned)
        record.validate()
        return record
