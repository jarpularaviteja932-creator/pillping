# Healthy Habit Tracker

A small, local-first Python application for tracking reading, exercise, and hydration across the week. It is designed for a clear classroom or hackathon demo: friendly terminal menus, careful validation, saved records, weekly analysis, charts, CSV import/export, and a Markdown report.

## Features

- Add or update one entry per date.
- Validate dates and sensible numeric ranges before saving.
- Save automatically to local JSON and keep a CSV copy.
- Search saved records by date, values, or notes.
- View weekly totals, daily averages, and goal-day counts.
- Generate a weekly Markdown report and a Matplotlib trend chart.
- Import legacy CSV files and see row-by-row errors.
- Recover gracefully if the JSON file is missing or damaged.
- Load 40 deterministic sample entries for a repeatable demo.

## Requirements

- Python 3.10 or newer
- Matplotlib 3.8+ for chart generation (the rest of the app uses the Python standard library)

## Run on macOS / Linux

```bash
python3 --version
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

## Run on Windows

```powershell
py -3 --version
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

## Suggested demo

1. Start the app and choose `6` to load 40 sample entries.
2. Choose `3` to display the weekly summary and create a chart/report.
3. Choose `1` to add or update a day. Try entering text for a number to show validation.
4. Choose `2` and search for a date or note.
5. Exit with `0`, relaunch, and show that the records remain saved.

## Data rules

| Habit | Unit | Accepted range | Default daily goal |
|---|---|---:|---:|
| Reading | Minutes | 0–1440 | 20 minutes |
| Exercise | Minutes | 0–1440 | 30 minutes |
| Hydration | Glasses | 0–30 | 8 glasses |

Weekly averages divide by all seven days, including days with no entry. Goal-day counts are calculated only from days that have an entry. These choices keep the report transparent.

## CSV format

The header must contain these columns:

```csv
entry_date,reading,exercise,hydration,note
2026-11-24,25,30,8,Walked and read
```

Dates use `YYYY-MM-DD`. A CSV import updates existing entries when the same date appears.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Project layout

```text
healthy_habit_tracker/
├── main.py
├── habit_tracker/
│   ├── __init__.py
│   ├── analytics.py
│   ├── cli.py
│   ├── models.py
│   └── storage.py
├── data/
├── charts/
├── reports/
├── tests/
├── requirements.txt
└── README.md
```

## Push to GitHub

1. Create a new empty repository on GitHub. Do not add a README there because this project already has one.
2. Open Terminal and move into this extracted project folder:
   ```bash
   cd path/to/healthy_habit_tracker
   ```
3. Initialize Git and make the first commit:
   ```bash
   git init
   git add .
   git commit -m "Build Healthy Habit Tracker"
   ```
4. Connect your GitHub repository (replace the URL with your own):
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/healthy-habit-tracker.git
   git push -u origin main
   ```
5. Refresh the GitHub repository page. Your source files and README should appear.

For later changes:
```bash
git add .
git commit -m "Describe your update"
git push
```

If Git asks you to sign in, complete the browser authentication prompt. Do not put your GitHub password or token inside the project files.

## Notes

This project is original starter code written for the supplied Healthy Habit Tracker brief. No tool can guarantee a particular AI-detector score or a 100% hackathon score. Be ready to explain the design, run the demo yourself, and adapt the goals or interface to your mentor's rubric.
